import CanvasContainer from "./components/CanvasContainer";

function App() {
  return (
    <>
      <div className="h-screen w-screen">
        <CanvasContainer />
      </div>
    </>
  );
}

export default App;
